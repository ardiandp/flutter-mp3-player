package com.example.fluttermusicplayermaster

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
