# Flutter Music Player
## Screenshots
<p>
  <img src="https://user-images.githubusercontent.com/96375955/188636956-4731f5f6-c054-477b-b4b5-dc36405e04b5.png" width="300">
  <img src="https://user-images.githubusercontent.com/96375955/188636970-e66deeb6-7f9f-4428-bfd1-8e35c8180dcf.png" width="300">
  <img src="https://user-images.githubusercontent.com/96375955/188637221-2c8b241a-cc0f-473e-b912-346eb00f2138.png" width="300">
  </p>
 


[Instagram](https://instagram.com/niima.dev)
## Getting Started

This project is a starting point for a Flutter application.

A few resources to get you started if this is your first Flutter project:

- [Lab: Write your first Flutter app](https://docs.flutter.dev/get-started/codelab)
- [Cookbook: Useful Flutter samples](https://docs.flutter.dev/cookbook)

For help getting started with Flutter development, view the
[online documentation](https://docs.flutter.dev/), which offers tutorials,
samples, guidance on mobile development, and a full API reference.
